The three networks were created in SamIam and are of the .net format v5.7 of Hugin. These can also be opened and saved with Genie.

The alternative networks that were found for each of the three example networks is found in the 'Alt Nets for Net ..' folders. The naming convention for the found networks is:

[arrow_count]_[permutation].net

To run the algorithm:

python BNexpander.py Network-X.net

This will create a new folder with the same root as BNexpander.py and fill it with all alternative representations.